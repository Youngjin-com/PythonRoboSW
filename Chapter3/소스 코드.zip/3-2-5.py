total = int(input("구매 총액: "))
vat = total * 0.10
print("구매 총액", total, "원의 부가가치세는", vat, "원입니다.")
