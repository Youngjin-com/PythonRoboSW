
import random
menus = [(1, '이상형 추가'), (2, '결정하기'), (3, '이상형 명단보기'),
         (4, '새로 입력하기'), (5, '종료')]
ideal = []
while True:
    for i, n in menus:
        print(i, n)
    c = int(input())
    if c == 1:
        s = input('당신의 이상형은? ')
        ideal.append(s)
    elif c == 2:
        print('당신의 이상형은', random.choice(ideal))
    elif c == 3:
        print (ideal)
    elif c == 4:
        ideal.clear()
    elif c == 5:
        break
