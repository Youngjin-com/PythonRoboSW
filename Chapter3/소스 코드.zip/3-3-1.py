passwd=1234
a=int(input("비밀번호를 입력하세요:"))
if passwd == a :
	print("상자가 열렸습니다, 보물획득")
else:
	print("비밀번호가 틀렸습니다")
