
grades = { }

while True:
        name = input("과목명: ")
        if not name:
                break;
        score = int(input("점수: "))
        grades[name] = score
sum,n = 0,0
for k, v in grades.items():
        print (k, v)
        sum = sum + v
        n = n + 1
print ('평균은', sum/n, '입니다')

