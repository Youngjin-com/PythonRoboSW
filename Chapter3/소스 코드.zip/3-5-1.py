def celcius_fahrenheit(temp):
    fahr = temp*9/5+32
    return fahr


