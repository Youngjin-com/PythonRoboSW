n = int(input('자연수 n: '))
sieve = [True] * n                 # sieve 리스트를 True로 초기화

for i in range(2, n):
    if sieve[i] == True:            # i가 소수인 경우
        print(i, end=' ')           # 소수 출력
        for j in range(i+i, n, i):    # i이후 i의 배수들을 False 판정
            sieve[j] = False