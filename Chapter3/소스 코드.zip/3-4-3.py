import random
menus = [(1, '영어 -> 한글'), (2, '한글 -> 영어'), (3, '종료')]
english_list = ['apple', 'bed', 'clock', 'cat', 'dog']
hangul_list = ['사과', '침대', '시계', '고양이', '개']
while True:
    for i, n in menus:
        print(i, n)
    c = int(input())
    if c == 1:
        n = random.randrange(5)
        eng_word = english_list[n]
        print('영어', eng_word, '의 뜻?')
        kor_word = input()
        if kor_word == hangul_list[n]:
            print('네 맞았어요, 영어', eng_word, '의 뜻은', kor_word, '입니다')
        else:
            print('틀렸습니다')
    elif c == 2:
        n = random.randrange(5)
        kor_word = hangul_list[n]
        print(kor_word, '은 영어로 무엇?')
        eng_word = input()
        if eng_word == english_list[n]:
            print('네 맞았어요,', kor_word, '은 영어로', eng_word, '입니다')
        else:
            print('틀렸습니다')
    elif c == 3:
        break
