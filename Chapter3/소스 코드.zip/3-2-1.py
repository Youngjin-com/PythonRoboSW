year = days = 365
weeks = days // 7
print ("일년은 ", days, "일이고", weeks, "주입니다")
