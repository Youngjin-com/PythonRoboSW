s1 = int(input("국어 점수:"))
s2 = int(input("영어 점수:"))
s3 = int(input("수학 점수:"))
s4 = int(input("과학 점수:"))

avg = (s1 + s2 + s3 + s4) / 4

print("성적 평균은", avg, "입니다")
