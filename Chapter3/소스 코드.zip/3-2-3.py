pi = 3.14159
r = int(input("반지름:"))
s = pi * r * r
print("반지름이 ", r, "인 원의 면적은 ", s, "입니다")
