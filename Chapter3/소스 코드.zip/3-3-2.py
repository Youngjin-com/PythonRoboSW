import turtle
t = turtle.Turtle()
n=0
while n < 4:
	t.forward(100)
	t.left(90)
	n = n + 1
